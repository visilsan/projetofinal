

const botao = document.getElementById('enviar');
const input = document.getElementById('limpar'